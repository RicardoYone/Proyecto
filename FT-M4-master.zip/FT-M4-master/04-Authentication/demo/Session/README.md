## Instrucciones

```bash
$ npm install
$ npm start
```

Abrir [http://localhost:3000/](http://127.0.0.1:3000/) para comenzar a utilizar la app.

Existe un usuario creado:

- __Email__: Franco@mail.com
- __Password__: 1234
