# Homework modelos relacionales

## Elegir un Schema

Tenés que diseñar el esquema entidad-relacion de por lo menos uno de estas web apps (o de alguna que vos conozcas):

```
Twitter
Gmail
Facebook
Instagram
Wordpress
Wikipedia
AirBnB
GitHub
Youtube
Spotify
Slack
```

## Donde diseñar

- [Genmy Models](https://www.genmymodel.com/database-diagram-online)
- [Google drawings](https://drawings.google.com/)

> Vas a tener que presentar tu diseño, asi que hacelo lindo!
> El trabajo se realiza en grupos de cuatro personas.

